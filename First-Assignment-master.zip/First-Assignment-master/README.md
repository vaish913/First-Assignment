# First-Assignment

This is your first GitHub based CBA Assignment.

**Write about your motivations and interests in Bioinformatics. What do you expect to gain from this association?**

## How to Submit your Assignments:
1. FORK the repository
2. CLONE the repository to your computer.
3. EDIT the assignment file (.txt) in your computer. (PLEASE DO NOT CHANGE THE NAME OF THE FILE)
4. Open the assignment repository in GitHub and UPLOAD your assignment file
5. Submit the URL to your GitHub repository that contains the completed assignment in the Excel sheet shared.

